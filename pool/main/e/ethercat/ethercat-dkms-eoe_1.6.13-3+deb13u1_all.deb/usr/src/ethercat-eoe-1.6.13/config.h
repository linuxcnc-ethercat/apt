/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.ac by autoheader.  */

/* Debug interfaces enabled */
/* #undef EC_DEBUG_IF */

/* Debug ring enabled */
/* #undef EC_DEBUG_RING */

/* EoE support enabled */
#define EC_EOE 1

/* Use CPU timestamp counter */
#define EC_HAVE_CYCLES 1

/* Use vendor id / product code wildcards */
#define EC_IDENT_WILDCARDS 1

/* Max. number of Ethernet devices per master */
#define EC_MAX_NUM_DEVICES 1

/* Read alias adresses from register */
/* #undef EC_REGALIAS */

/* RTDM interface enabled */
/* #undef EC_RTDM */

/* Use Xenomai3 RTDM flavour */
/* #undef EC_RTDM_XENOMAI_V3 */

/* Output to syslog in RT context */
#define EC_RT_SYSLOG 1

/* Assign SII to PDI */
#define EC_SII_ASSIGN 1

/* Use hrtimer for scheduling */
#define EC_USE_HRTIMER 1

/* Define to 1 if you have the <dlfcn.h> header file. */
#define HAVE_DLFCN_H 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdio.h> header file. */
#define HAVE_STDIO_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define to the sub-directory where libtool stores uninstalled libraries. */
#define LT_OBJDIR ".libs/"

/* Name of package */
#define PACKAGE "ethercat"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "fp@igh.de"

/* Define to the full name of this package. */
#define PACKAGE_NAME "ethercat"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "ethercat 1.6.13"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "ethercat"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "1.6.13"

/* Define to 1 if all of the C89 standard headers exist (not just the ones
   required in a freestanding environment). This macro is provided for
   backward compatibility; new code need not use it. */
#define STDC_HEADERS 1

/* Version number of package */
#define VERSION "1.6.13"
